//Create a reference for canvas 
var canvashold = document.getElementById("canvas1");
ctx = canvashold.getContext("2d");
//Give specific height and width to the car image
var carh = 150;
var carw = 150;

backgroundimg = "parkingLot.jpg";
greencar_image = "car2.png";

//Set initial position for a car image.
var carx = 200;
var cary = 500;
function add() {
	//upload car, and background images on the canvas.
backimgvar = new Image();
backimgvar.onload = uploadBackground;
backimgvar.src = backgroundimg;

carimgvar = new Image();
carimgvar.onload = uploadgreencar;
carimgvar.src = greencar_image;
}

function uploadBackground() {
	//Define function ‘uploadBackgroundground’
	ctx.drawImage(backimgvar,0,0,canvashold.width,canvashold.height);
}

function uploadgreencar() {
	//Define function ‘uploadgreencar’.
    ctx.drawImage(carimgvar,carx,cary,carw,carh);
}


window.addEventListener("keydown", my_keydown);

function my_keydown(e)
{
	keyPressed = e.keyCode;
	console.log(keyPressed);
		if(keyPressed == '38')
		{
			up();
			console.log("up");
		}
	
		if(keyPressed == '40')
		{
			down();
			console.log("down");
		}
		
		if(keyPressed == '37')
		{
			left();
			console.log("left");
		}
	
		if(keyPressed == '39')
		{
			right();
			console.log("right");
		}
		
		
}

function up() {
    if(cary >= 0){
        cary = cary - 10;
        console.log("x =" + carx + "y =" + cary);
        uploadBackground();
        uploadgreencar();
    }
}

function down() {
    if(cary <= 720){
        cary = cary + 10;
        console.log("x =" + carx + "y =" + cary);
        uploadBackground();
        uploadgreencar();
    }
}

function left() {
    if(carx >= 0){
        carx = carx - 10;
        console.log("x =" + carx + "y =" + cary);
        uploadBackground();
        uploadgreencar();
    }
}

function right() {
    if(carx <= 1280){
        carx = carx + 10;
        console.log("x =" + carx + "y =" + cary);
        uploadBackground();
        uploadgreencar();
    }
}